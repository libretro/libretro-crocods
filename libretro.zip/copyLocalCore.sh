#!/bin/bash

path="../Pods/CrocoDS-Core/CrocoDS-Core/"

echo $currentdir

echo cp $path"*.c" crocods
echo cp $path"*.h" crocods

